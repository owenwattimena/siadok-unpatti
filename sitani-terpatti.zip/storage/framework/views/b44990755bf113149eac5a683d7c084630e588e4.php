<!DOCTYPE html>
<html>
<head>
    <title>LAPORAN ALUMNI</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <style type="text/css">
        body { margin: 0px; }
        * {
            font-family: Arial, Helvetica, sans-serif !important;
            font-size: 12px !important;
        }
        hr {
            border-top: 3px solid black;
        }
        h1 {
            font-weight: bold;
        }
        #table,
        #table th,
        #table td {
            border: 0.3px solid #444444 !important;
        }
        #table th, .center{
            text-align: center;
        }
    </style>
    <center>
        <h1>LAPORAN ALUMNI<br>MAHASISWA KEDOKTERAN<br>UNIVERSITAS PATTIMURA</h1>
    </center>
    <?php echo $filter; ?>

    <table class='table table-bordered' id="table">
        <thead>
            <tr>
                <th style="width: 30px">NO</th>
                <th>NIM</th>
                <th>NAMA</th>
                <th>TAHUN MASUK</th>
                <th>TAHUN LULUS</th>
                <th>KOTA</th>
                <th>TEMPAT KERJA</th>
                <th>PEKERJAAN SEBELUMNYA</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1 ?>
            <?php $__currentLoopData = $alumnus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="center"><?php echo e($i++); ?></td>
                <td class="center"><?php echo e($item->nim); ?></td>
                <td><?php echo e($item->nama_lengkap); ?></td>
                <td class="center"><?php echo e($item->tahun_masuk_s1); ?></td>
                <td class="center"><?php echo e($item->tahun_lulus_s1); ?></td>
                <td><?php echo e($item->kota_kabupaten); ?></td>
                <td><?php echo e($item->tempat_kerja); ?></td>
                <td><?php echo e($item->wahana_internship); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/report/pdf.blade.php ENDPATH**/ ?>