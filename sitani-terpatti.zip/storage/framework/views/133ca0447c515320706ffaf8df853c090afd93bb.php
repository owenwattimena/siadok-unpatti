<footer class="bg-dark text-light">
    <section class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-2">
                        <img src="https://2.bp.blogspot.com/-AIyrDO0XSJU/V9PTDKcnkmI/AAAAAAAAAGk/ggxfySu5adogvhjoGgk9muXYgSYTEXtQACLcB/s1600/AM%2BLogo_2.png"
                            width="100" alt="">
                    </div>
                    <div class="col-md-10">
                        <h1>Ranting 3 - Menara Kasih</h1>
                        <h3>ANGKATAN MUDA GEREJA PROTESTAN MALUKU</h3>
                        <span>Jl. Ir. M. Putuhena - Wayame</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <p class="text-center mb-0 py-3 copyright">
        Copyright &copy; AMGPM Ranting 3 - 2021
    </p>
</footer>
<?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/web/templates/footer.blade.php ENDPATH**/ ?>