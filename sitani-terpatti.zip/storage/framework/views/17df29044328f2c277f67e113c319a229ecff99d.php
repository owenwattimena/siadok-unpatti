

<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Kota/Kabupaten
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Kota/Kabupaten</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <?php if(session('status')): ?>
        <div class="alert alert-<?php echo session('status'); ?> alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo session('message'); ?>

        </div>
        <?php endif; ?>
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Daftar Kota/Kabupaten</h3>
                <button class="btn btn-sm bg-blue pull-right" onclick="createModal()" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Tambah</button>
                <?php echo $__env->make('admin.city.component.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th style="width: 30px">#</th>
                            <th>KOTA/KABUPATEN</th>
                            <th>KETERANGAN</th>
                            <th>PILIHAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($item->city_name); ?></td>
                            <td><?php echo e($item->description ?? '-'); ?></td>
                            <td>
                                <button class="btn btn-sm bg-orange" onclick='return updateModal(<?php echo e($item->id); ?>, "<?php echo e($item->city_name); ?>", "<?php echo e($item->description); ?>")' data-toggle="modal" data-target="#modal-default"><i class="fa fa-edit"></i> Ubah</button>
                                <form action="<?php echo e(route('city.delete', $item->id)); ?>" style="display: inline;" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus lokasi <?php echo e($item->city_name); ?>?')"><i class="fa fa-trash"></i> Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- DataTables -->
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example1').DataTable();
    })
    
    createModal = ()=>{
        resetForm();
    }
    
    updateModal = (cityId, cityName, description) => {
        $('input[name=_method]').val('PUT');
        $('form').attr('action', `<?php echo e(url('city')); ?>/` + cityId);
        $('.modal-title').text('Update Kota/Kabupaten');
        $('#city').val(cityName);
        $('#description').val(description);
    }
    resetForm = ()=>{
        $('form').trigger("reset");
        $('form').attr('action', `<?php echo e(url('city')); ?>`);
        $('input[name=_method]').val('POST');
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/city/index.blade.php ENDPATH**/ ?>