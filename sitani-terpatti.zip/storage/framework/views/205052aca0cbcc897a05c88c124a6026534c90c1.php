
<div class="row">
    <div class="col-md-4">
        <div class="box box-widget widget-user">
            <div class="widget-user-header bg-red">
                
            </div>
            <div class="widget-user-image" style="margin-left: -70px; top:50px">
                <img class="img-circle" style="width: 140px; height: 140px" src="<?php echo e(asset('assets/img/no-profile-image.png')); ?>" alt="User Avatar">
            </div>
            <div class="box-footer">
                <div class="row" style="margin-top: 60px">
                    <div class="col-sm-12">
                        <?php if(request()->is('alumni*')): ?>
                            
                        <form id="upload-image-form" action="" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="nim" id="h_nim">
                            <input type="file" name="photo" class="pull-left" required>
                            <button class="pull-right">Ubah</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="name">Name<span class="text-red">*</span></label>
            <input type="text" disabled class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="[Nama]" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="nim">NIM<span class="text-red">*</span></label>
            <input type="number" disabled class="form-control" id="nim" name="nim" value="<?php echo e(old('nim')); ?>" placeholder="[NIM]" required>
            <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="form-group">
            <label for="email">Email<span class="text-red">*</span></label>
            <input type="email" disabled class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="[Email]" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="entry_year">Tahun Masuk</label>
            <input type="number" disabled min="2000" max="3000" class="form-control" id="entry_year" name="entry_year" value="<?php echo e(old('entry_year')); ?>" placeholder="[Tahun Masuk]">
            <?php $__errorArgs = ['entry_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="graduation_year">Tahun Lulus</label>
            <input type="number" disabled min="2000" max="3000" class="form-control" id="graduation_year" name="graduation_year" value="<?php echo e(old('graduation_year')); ?>" placeholder="[Tahun Lulus]">
            <?php $__errorArgs = ['graduation_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label for="previous_job">Riwayat Pekerjaan</label>
            <textarea class="form-control" disabled id="previous_job" name="previous_job" rows="3" placeholder="[Pekerjaan Sebelumnya]"><?php echo e(old('previous_job')); ?></textarea>
            <?php $__errorArgs = ['previous_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="workplace">Tempat Kerja</label>
            <input type="text" disabled class="form-control select2" id="workplace" name="workplace" placeholder="[Tempat Kerja]">
            <?php $__errorArgs = ['workplace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="city">Kota/Kabupaten</label>
            <input type="text" disabled class="form-control" id="city" name="city">
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <label for="map">Peta Lokasi Tempat Kerja</label>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <input type="number" disabled step="any" class="form-control" id="latitude" name="latitude" placeholder="[Latitude]">
                    <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="number" disabled step="any" class="form-control" id="longitude" name="longitude" placeholder="[Longitude]">
                    <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div id="detail_map" class="map" style="height: 500px"></div>
    </div>
</div><?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/alumni/component/detail_form.blade.php ENDPATH**/ ?>