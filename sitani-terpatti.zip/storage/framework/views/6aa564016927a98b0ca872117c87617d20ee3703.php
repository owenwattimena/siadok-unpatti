
<link rel="stylesheet" href="<?php echo e(asset('assets/app-css/modal.css')); ?>">


<div class="modal fade" id="modal-default">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            
                
                
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title">Tambah Alumni</h4>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <?php echo $__env->make('admin.alumni.component.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                
            
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/alumni/component/create_modal.blade.php ENDPATH**/ ?>