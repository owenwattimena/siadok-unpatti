<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="info" style="position: static; text-align: center">
                <p><i class="fa fa-user-circle"></i> <?php echo e(\Auth::user()->name); ?></p>
                <!-- Status -->
                
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e((request()->is('dashboard*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-map"></i> <span>Peta</span></a></li>
            
            <li class="treeview <?php echo e(((request()->is('city*')) || (request()->is('alumni*'))) ? 'active' : ''); ?>">
                <a href="#"><i class="fa fa-list"></i> <span>Master Data</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e((request()->is('city*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('city.index')); ?>"><i class="fa fa-map-marker"></i> Kota/Kabupaten</a></li>
                    <li class="<?php echo e((request()->is('alumni*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('alumni.index')); ?>"><i class="fa fa-users"></i> Alumni</a></li>
                </ul>
            </li>
        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/templates/aside.blade.php ENDPATH**/ ?>