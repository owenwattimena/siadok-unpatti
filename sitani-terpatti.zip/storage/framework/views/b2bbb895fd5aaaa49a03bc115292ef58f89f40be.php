<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/leaflet.js"></script>
<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-fullscreen/v1.0.1/Leaflet.fullscreen.min.js'></script>
<script src="<?php echo e(asset('assets/dist/js/leafletjs-label.js')); ?>"></script><?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/assets/js/leaflet.blade.php ENDPATH**/ ?>