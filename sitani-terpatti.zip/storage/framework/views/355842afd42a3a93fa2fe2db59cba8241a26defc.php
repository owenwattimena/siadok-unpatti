

<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            User
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">User</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <?php if(session('status')): ?>
        <div class="alert alert-<?php echo session('status'); ?> alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo session('message'); ?>

        </div>
        <?php endif; ?>
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Daftar User</h3>
                <button class="btn btn-sm bg-blue pull-right" onclick="createModal()" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Tambah</button>
                <?php echo $__env->make('admin.user.component.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin.user.component.password-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th style="width: 30px">#</th>
                            <th>NAMA</th>
                            <th>USERNAME</th>
                            <th>EMAIL</th>
                            <th>LEVEL</th>
                            <th>PILIHAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->username); ?></td>
                            <td><?php echo e($item->email ?? '-'); ?></td>
                            <td><?php echo e($item->role); ?></td>
                            <td>
                                <button class="btn btn-sm bg-orange" onclick='updateModal(<?php echo e($item->id); ?>, "<?php echo e($item->name); ?>", "<?php echo e($item->username); ?>", "<?php echo e($item->email); ?>", "<?php echo e($item->role); ?>")' data-toggle="modal" data-target="#modal-default"><i class="fa fa-edit"></i> Ubah</button>
                                <button class="btn btn-sm bg-black" onclick='changePassword(<?php echo e($item->id); ?>)' data-toggle="modal" data-target="#modal-password"><i class="fa fa-key"></i> Ubah Password</button>
                                <form action="<?php echo e(route('user.delete', $item->id)); ?>" style="display: inline;" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus user <?php echo e($item->username); ?>?')"><i class="fa fa-trash"></i> Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- DataTables -->
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        

        <?php if($errors->update->any()): ?>
            setTimeout(function() {
                updateModal();
                $('#modal-default').modal('show');
            }, 400);

        <?php elseif($errors->password->any()): ?>
            changePassword(`<?php echo e(old('user_id')); ?>`);
            $('#modal-password').modal('show');
        <?php elseif($errors->any()): ?>
            setTimeout(function() {
                $('#modal-default').modal('show');
            }, 400);
        <?php endif; ?>
        $('#example1').DataTable();
    })
    
    createModal = ()=>{
        resetForm();
        $('.modal-title').text('Tambah User');
        hidePasswordField(false);
    }
    changePassword = (id)=>{
        $('#user_id_form').val(id);
        $('#form-password').attr('action', `<?php echo e(url('user/change-password')); ?>/` + id);
    }
    
    function updateModal(userId = null, nama = null, username = null, email = null, role = null){
        $('form').attr('action', `<?php echo e(url('user')); ?>/` + userId);
        $('input[name=_method]').val('PUT');
        $('.modal-title').text('Update User');
        hidePasswordField();
        if(userId != null)
        {
            $('input[name=name]').val(nama);
            $('input[name=username]').val(username);
            $('input[name=email]').val(email);
            $('select[name=level]').val(role);
        }
    }
    function resetForm(){
        $('#form')[0].reset();
        $('input[name=name]').val("");
        $('input[name=username]').val("");
        $('input[name=email]').val("");
        $('select[name=level]').val("admin");
        $('form').attr('action', `<?php echo e(url('user')); ?>`);
        $('input[name=_method]').val('POST');
    }

    hidePasswordField = (state = true)=>{
        if(state){
            $('#password').hide();
            $('#password_confirmation').hide();
            $('label[for=password]').hide();
            $('label[for=password_confirmation]').hide();
            $('#password').attr('required', false);
            $('#password_confirmation').attr('required', false);
        }else{
            $('#password').show();
            $('#password_confirmation').show();
            $('label[for=password]').show();
            $('label[for=password_confirmation]').show();
            $('#password').attr('required', true);
            $('#password_confirmation').attr('required', true);
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sitani-terpatti\resources\views/admin/user/index.blade.php ENDPATH**/ ?>