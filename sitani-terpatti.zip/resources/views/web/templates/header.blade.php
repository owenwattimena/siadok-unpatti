<header>
    <div class="jumbotron jumbotron-fluid p-5 mb-0">
        <div class="container text-center">
            <img src="https://2.bp.blogspot.com/-AIyrDO0XSJU/V9PTDKcnkmI/AAAAAAAAAGk/ggxfySu5adogvhjoGgk9muXYgSYTEXtQACLcB/s1600/AM%2BLogo_2.png"
                width="78" alt="">
            <h1 class="">Ranting 3</h1>
            <h3>AM CABANG MENARA KASIH</h3>
            <h2>GEREJA PROTESTAN MALUKU</h2>
        </div>
    </div>
</header>
