<script src="{{ asset('assets/plugins/leaflet/leaflet.js') }}"></script>
<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-fullscreen/v1.0.1/Leaflet.fullscreen.min.js'></script>
<script src="{{ asset('assets/dist/js/leafletjs-label.js') }}"></script>